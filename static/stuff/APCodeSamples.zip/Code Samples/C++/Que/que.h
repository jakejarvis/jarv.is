#include <iostream>

using namespace std;

class que
{
public:
	que();
	void push(int x);
	int pop();
	bool isEmpty();
	int top();

private:
	int size;
	int array[20];
};