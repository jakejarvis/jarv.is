#include <iostream>
#include "stdlib.h"
#include "que.h"

using namespace std;

int main()
{
	int x;
	char opt;
	que myqueue;

	while(true)
	{
		cout << "Enter a number: ";
		cin >> x;
		myqueue.push(x);
		cout << "Current top: " << myqueue.top()
			 << "\n";

		cout << "Enter another? (Y/N) ";
		cin >> opt;
		opt = toupper(opt);

		if (opt == 'N')
		{
			break;
		}

		cout << "\n";
	}

	while (!myqueue.isEmpty())
	{
		cout << "\nPopped... " << myqueue.pop() << endl;
	}

	cout << "\n\n";

	return 0;
}