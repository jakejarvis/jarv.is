#include <iostream>
#include "que.h"

que::que()
{
	size = 0;
}

void que::push(int x)
{
	//cout << "size: " << size;
	array[size] = x;
	size++;
}

int que::top()
{
	return array[0];
}

bool que::isEmpty()
{
	if(size == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

int que::pop()
{
	//int pop = array[size-1];
	int p = array[0];
	for(int i=0; i<size; i++)
	{
		array[i] = array[i+1];
	}

	//int pop = array[i];

	array[size-1] = 0;
	size--;

	return p;
}