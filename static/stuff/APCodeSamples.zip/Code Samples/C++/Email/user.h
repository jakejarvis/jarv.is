#ifndef _USER_
#define _USER_

#include <iostream>
#include <string>
#include "email.h"
using namespace std;

class user
{
public:
	user();
	user(string uname, string pword);

	void setUsername(string uname);
	void setPassword(string pword);

	string getUsername();
	string getPassword();

	bool checkPassword(string pword);
	void checkEmail();

	void receiveEmail(email temail);

	void writeFile();

private:
	string username;
	string password;
	email emails[90];
	int emailsize;
};

#endif