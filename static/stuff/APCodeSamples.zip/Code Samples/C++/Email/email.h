#ifndef _EMAIL_
#define _EMAIL_

#include <iostream>
#include <string>
using namespace std;

class email
{
friend ostream &operator<<(ostream &out, email &rhs);
friend istream &operator>>(istream &in, email&rhs);

public:
	email();

	void setInfo(string sub, string msg, string send);
	
	string getSubject();

private:
	string subject, message, sender;

};

#endif