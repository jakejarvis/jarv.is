#include <iostream>
#include <fstream>
#include "user.h"
#include "email.h"

using namespace std;

void writeFile(user users[20], int size);
void readFile(user users[20], int &size);

int main()
{
	user users[20];
	user login;
	/*email temp;
	cin>>temp;
	cout<<temp;*/

	int size=0;
	readFile(users, size);
	
	cout << "***************************************\n"
		 << "*                                     *\n"
		 << "*             JMail v1.0              *\n"
		 << "*                                     *\n"
		 << "***************************************\n\n";

	int choice;
	string uname;
	string pword;

	while(true)
	{
		cout << "Enter an option:\n"
			<< "1. Create an Account\n"
			<< "2. Login to an Existing Account\n"
			<< "3. Quit\n\n"
			<< "Choice: ";

		cin >> choice;
		cout << "\n";

		switch(choice)
		{
		case 1:
			while(true)
			{
				system("cls");
				cout << "***************************************\n"
					<< "*            Registration             *\n"
					<< "***************************************\n\n";

				cout << "Username: ";
				cin >> uname;
				
				cout << "Password: ";
				cin >> pword;
				
				int i;
				for(i=0; i<size; i++)
				{
					if(users[i].getUsername() == uname)
					{
						break;
					}
				}

				if(i != size)
				{
					cout << "Username already registered!\n\n";
					system("PAUSE");
				}
				else
				{
					users[size].setUsername(uname);
					users[size].setPassword(pword);
					size++;

					system("cls");

					cout << "***************************************\n"
						 << "*              Main Menu              *\n"
						 << "***************************************\n\n";

					break;
				}

				system("cls");
			}

			break;
		case 2:
			system("cls");
			cout << "***************************************\n"
				 << "*                Login                *\n"
				 << "***************************************\n\n";

			cout << "Username: ";
			cin >> uname;
			
			cout << "Password: ";
			cin >> pword;

			cout << "\n";
			int z;
			for(z=0; z<size; z++)
			{
				if(users[z].getUsername() == uname)
				{
					if(users[z].checkPassword(pword))
					{
						cout << "Login successful!";
						login = users[z];
						break;
					}
				}
			}
			
			if(z==size)
			{
				cout << "Invalid login information!\n\n";
			}
			else
			{
				system("cls");
				cout << "*      Welcome, " << login.getUsername() << "!      *\n\n";

				bool quit = false;
				string subject, message, username, term;

				while(true)
				{
					system("cls");

					cout << "***************************************\n"
						 << "*              Main Menu              *\n"
						 << "***************************************\n\n";

					cout << "Enter an option:\n"
						<< "1. Check for new mail\n"
						<< "2. Send a message\n"
						<< "3. Logout\n\n";

					cout << "Choice: ";
					cin >> choice;

					email temp;
					int pos;

					string to, subject, message;

					switch(choice)
					{
					case 1:
						login.checkEmail();
						break;
					case 2:
						system("cls");

						cout << "***************************************\n"
							<< "*            Send a Message           *\n"
							<< "***************************************\n\n";

						cout << "To: ";
						getline(cin, to);
						getline(cin, to);
						
						cout << "Subject: ";
						getline(cin, subject);

						cout << "Message: ";
						getline(cin, message);
						
						system("cls");

						int j;
						for(j=0; j<size; j++)
						{
							if(users[j].getUsername() == to)
							{
								pos = j;
								break;
							}
						}

						if(j==size)
						{
							system("cls");
							cout << "\nUser doesn't exist!\n\n";
						}
						temp.setInfo(subject, message, login.getUsername());
						users[pos].receiveEmail(temp);

						break;
					case 3:
						system("cls");

						cout << "***************************************\n"
							<< "*               Goodbye!              *\n"
							<< "***************************************\n\n";

						system("PAUSE");
						system("cls");

						cout << "***************************************\n"
							<< "*              Main Menu              *\n"
							<< "***************************************\n\n";

						quit = true;
						break;
					default:
						system("cls");
						cout << "Please enter a valid option.\n\n";
					}

					if(quit == true)
					{
						break;
					}
				}

			}
			break;
		case 3:
			writeFile(users, size);

			system("cls");

			cout << "***************************************\n"
				<< "*               Goodbye!              *\n"
				<< "***************************************\n\n";

			system("PAUSE");
			return 0;
		default:
			system("cls");
			cout << "Please enter a valid option.";
		}
	}
	return 0;
}

void writeFile(user users[20], int size)
{
	ofstream unamefile("info\\usernames.jm");

	for(int i=0; i<size; i++)
	{
		unamefile << users[i].getUsername() << endl;
	}

	unamefile.close();

	for(int i=0; i<size; i++)
	{
		users[i].writeFile();
	}
}

void readFile(user users[20], int &size)
{
	fstream uname("info\\usernames.jm"), unamefile[20];
	string names[20], temp, password, filename;
	email emailtemp;

	while(uname.good())
	{
		if(uname>>temp)
		{
			names[size]=temp;
			size++;
		}
	}

	/*for(int i=0; i<size; i++)
	{
		cout << names[i] << endl;
	}

	cout << size;*/

	for(int i=0; i<size; i++)
	{
		filename = "info\\" + names[i] + ".jm";
		unamefile[i].open(filename.c_str());
		getline(unamefile[i], password);
		user tempuser(names[i], password);
		users[i] = tempuser;
		while(unamefile[i].good() && unamefile[i]>>emailtemp)
		{
			users[i].receiveEmail(emailtemp);
		}
		unamefile[i].close();
	}
}