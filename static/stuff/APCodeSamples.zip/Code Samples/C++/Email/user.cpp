#include <iostream>
#include <string>
#include <fstream>
#include "user.h"
#include "email.h"

user::user()
{
	username = "";
	password = "";
	emailsize = 0;
}

user::user(string uname, string pword)
{
	username = uname;
	password = pword;
	emailsize = 0;
}

void user::setUsername(string uname)
{
	username = uname;
}

void user::setPassword(string pword)
{
	password = pword;
}

string user::getUsername()
{
	return username;
}

string user::getPassword()
{
	return password;
}

bool user::checkPassword(string pword)
{
	if(pword == password)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void user::receiveEmail(email temail)
{
	emails[emailsize] = temail;
	emailsize++;
}

void user::checkEmail()
{
	int choice;

	while(true)
	{
		system("cls");

		cout << "***************************************\n"
			<< "*                Inbox                *\n"
			<< "***************************************\n\n";

		cout << "Which message would you like to read?\n";

		for(int i=0; i<emailsize; i++)
		{
			cout << i << ". ";
			cout << emails[i].getSubject()<<endl;
		}

		cout << "\nChoice: ";
		cin >> choice;
		cout << "\n";

		if(choice>=emailsize || choice<0)
		{
			cout << "Invalid message.\n\n";
			system("PAUSE");
		}
		else
		{
			system("cls");

			cout << "***************************************\n"
				<< "*           Reading email...          *\n"
				<< "***************************************\n\n";

			cout << emails[choice];

			cout << "\n\n";
			system("PAUSE");
			break;
			system("cls");
		}
	}
}

void user::writeFile()
{
	string filename;

	filename = "info\\" + username + ".jm";
	
	ofstream uinfo(filename.c_str());

	uinfo << password;

	int i;
	for(i=0; i<emailsize; i++)
	{
		uinfo << endl <<emails[i];
	}

	uinfo.close();
}