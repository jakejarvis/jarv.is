#include <iostream>
#include <string>
#include "email.h"

email::email()
{

}

void email::setInfo(string sub, string msg, string send)
{
	subject = sub;
	message = msg;
	sender = send;
}

ostream &operator<<(ostream &out, email &rhs)
{
	out << "From: " << rhs.sender << endl;
	out << "Subject: " << rhs.subject << endl;
	out << "Message: " << rhs.message;

	return out;
}

istream &operator>>(istream &in, email &rhs)
{
	string temp;
	getline(in, temp);
	rhs.sender = temp.substr(6, temp.length());

	getline(in, temp);
	rhs.subject = temp.substr(9, temp.length());

	getline(in, temp);
	rhs.message = temp.substr(9, temp.length());

	return in;
}

string email::getSubject()
{
	return subject;
}