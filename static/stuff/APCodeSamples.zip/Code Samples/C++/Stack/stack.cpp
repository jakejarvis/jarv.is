#include <iostream>
#include "stack.h"

stack::stack()
{
	size = 0;
	array[20] = 0;
}

void stack::push(char x)
{
	array[size] = x;
	size++;
}

char stack::top()
{
	return array[size-1];
}

bool stack::isEmpty()
{
	if(size == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

char stack::pop()
{
	char pop = array[size-1];
	array[size-1] = 0;
	size--;
	return pop;
}