#include <iostream>

using namespace std;

class stack
{
public:
	stack();
	void push(char x);
	char pop();
	bool isEmpty();
	char top();

private:
	int size;
	char array[20];
};