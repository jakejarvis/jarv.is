#include <iostream>
#include <string>
#include "stack.h"

using namespace std;

int main()
{
	string problem;
	stack mystack;
	bool valid = true;

	cout << "Enter a math problem: ";
	cin >> problem;

	for(int i = 0; i < problem.length(); i++)
	{
		if(problem[i] == '(')
		{
			mystack.push('(');
		}
		else if(problem[i] == '[')
		{
			mystack.push('[');
		}
		else if(problem[i] == '{')
		{
			mystack.push('{');
		}

		if(problem[i] == ')')
		{
			if (mystack.top()=='(')
			{
				mystack.pop();
			}
			else
			{
				valid = false;
				cout << "No matching " << mystack.top() << " found.\n\n";
				break;
			}
		}
		else if(problem[i] == ']')
		{
			if (mystack.top()=='[')
			{
				mystack.pop();
			}
			else
			{
				valid = false;
				cout << "No matching " << mystack.top() << " found.\n\n";
				break;
			}
		}
		else if(problem[i] == '}')
		{
			if (mystack.top()=='{')
			{
				mystack.pop();
			}
			else
			{
				valid = false;
				cout << "No matching " << mystack.top() << " found.\n\n";
				break;
			}
		}
	}

	if (valid == true)
	{
		cout << "\nValid math problem!\n\n";
	}

	return 0;
}