<b>My MySQL Blog</b><br>
<br>
<?php
	$conn = mysql_connect ('localhost', 'jarvis_projects', 'jake0206')
		or die ("Could not connect to server localhost.");

	mysql_select_db ('jarvis_projects', $conn)
		or die ("Could not select database jarvis_projects.");

	$query = "INSERT INTO blog (author, title, message) VALUES ('$author', '$title', '$message')";
	
	mysql_query ($query)
		or die ($query);

	mysql_close ($conn);
?>
Successful! <a href="blog.php">Click here.</a>