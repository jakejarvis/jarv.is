<?php
	if($username == "special" && $password == "person")
	{
		echo "You've reached the super special page!";
	}
	else
	{
		echo "Sorry, your login failed. <a href=\"password.php\">Try again</a>?";
	}
?>