<b>Star Project</b><br>
<br>
<form action="star_submit.php" method="post">
<input type="text" name="num"><br>
<br>
<input type="submit" value="Submit!">
</form>