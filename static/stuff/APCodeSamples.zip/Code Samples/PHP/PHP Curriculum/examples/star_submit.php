<b>Part I:</b><br>
<br>
<?php
for($count = 0; $count < $num; $count = $count+1)
{
echo "* ";
}
?>
<br><br>
<b>Part II:</b><br>
<br>
<?php
for($count = 0; $count < $num; $count = $count + 1)
{
	for($count2 = 0; $count2 < $num; $count2 = $count2 + 1)
	{
		echo "* ";
	}
	echo "<br>";
}
?>
<br><br>
<b>Part III:</b><br>
<br>
<?php
for($count = 0; $count < $num; $count = $count + 1)
{
	for($count2 = 0; $count2 < $count; $count2 = $count2 + 1)
	{
		echo "* ";
	}
	echo "<br>";
}
?>