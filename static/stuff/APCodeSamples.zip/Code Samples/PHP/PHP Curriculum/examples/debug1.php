<php method="start">

string true="false";

echo = {This PHP class is awesome!;

if{$treu="yes"} mail{"jake@jakejarvis.com; hahaha i bet this works'}
else(1=3]
(
mail[reallycoolkid@ulc.com. 'hello really cool kid. i'm a really cool programmer.]
);

while 8-8=nothing
[shut_down("computer")];

echo "hahaha i win'

</php>