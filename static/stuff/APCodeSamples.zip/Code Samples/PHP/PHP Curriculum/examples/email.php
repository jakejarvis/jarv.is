<b>Email Client</b><br>
<br>
<form action="email_submit.php" method="post">
<table>
<tr>
<td>
<b>To:</b>
</td>
<td>
<input type="text" name="to">
</td>
</tr>

<tr>
<td>
<b>Subject:</b>
</td>
<td>
<input type="text" name="subject">
</td>
</tr>

<tr>
<td>
<b>Message:</b>
</td>
<td>
<textarea name="message"></textarea>
</td>
</tr>

<tr>
<td colspan="2">
<input type="submit" value="Send!">
</td>
</tr>
</table>
</form>