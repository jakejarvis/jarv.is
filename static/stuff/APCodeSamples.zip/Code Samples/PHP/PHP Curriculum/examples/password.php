<b>I'm watching you...</b>

<form action="password_submit.php" method="post">
Username: <input type="text" name="username"><br>
Password: <input type="password" name="password"><br>
<br>
<input type="submit" value="Try to get in...">
</form>