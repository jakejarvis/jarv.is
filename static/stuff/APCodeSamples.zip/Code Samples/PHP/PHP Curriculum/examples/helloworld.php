<?php
	echo "Hello, World!";
?>