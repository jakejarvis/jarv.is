<b>Mad Lib</b><br>
<br>
<form action="madlib_submit.php" method="post">
Object/Person: <input type="text" name="noun1"><br>
Place: <input type="text" name="place"><br>
Object: <input type="text" name="noun2"><br>
Expression: <input type="text" name="exp"><br><br>
<input type="submit" value="Let's see...">
</form>




