<b>Awesome Advanced Calculator</b>
<form action="advcalc_submit.php" method="post">
<input type="text" name="num1" size="5"> 
<select name="oper">
	<option value="+">+
	<option value="-">-
	<option value="*">*
	<option value="/">/
</select> 
<input type="text" name="num2" size="5"> = 
<input type="submit" value="Let's find out...">
</form>