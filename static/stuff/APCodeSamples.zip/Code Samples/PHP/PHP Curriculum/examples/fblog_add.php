<b>My Blog</b><br>
<form action="fblog_submit.php" method="post">
<table>
<tr>
<td>
Author:
</td>

<td>
<input type="text" name="author">
</td>
</tr>

<tr>
<td>
Title:
</td>

<td>
<input type="text" name="title">
</td>
</tr>

<tr>
<td>
Message:
</td>

<td>
<textarea name="message"></textarea>
</td>
</tr>

<tr>
<td colspan="2">
<input type="submit" value="Add!">
</td>
</tr>
</table>
</form>