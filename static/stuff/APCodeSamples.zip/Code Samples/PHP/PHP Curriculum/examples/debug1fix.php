<?php

$true="false";

echo "This PHP class is awesome!";

if($true="yes")
{
	mail("blah@blah.com", "missing subject", "hahaha i bet this works");
}
else
{
	mail("blah@blah.com", "missing subject", "hello really cool kid. i'm a really cool programmer");
}

for($myvar = 0; $myvar < 2; $myvar = $myvar+1)
{
	echo "I tried to shut down your computer using a non-existant command, and I failed.";
}

echo "hahaha i win";

?>