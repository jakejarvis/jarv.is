<b>Awesome Advanced Calculator</b><br><br>
<?php
if($oper=="+")
{
	$ans=$num1+$num2;
}
else if($oper=="-")
{
	$ans=$num1-$num2;
}
else if($oper=="*")
{
	$ans=$num1*$num2;
}
else
{
	$ans=$num1/$num2;
}
echo $num1 . " " . $oper . " " . $num2 . " = " . "<b>" . $ans . "</b>";
?>