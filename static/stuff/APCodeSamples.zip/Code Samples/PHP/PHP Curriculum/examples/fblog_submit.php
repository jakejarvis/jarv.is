<b>My Blog</b><br>
<?php
      $open = fopen("fblog.html", "r+");
      $read = fread($open, 256);

      fwrite($open, "<b>$title</b><br>$message<br><br>Posted by $author<br><br><hr>");
?>
<br>
Successful! <a href="fblog.html">Click here.</a>