<b>Simple Calculator (Addition)</b><br>
<br>
<?php
	$result = $n1+$n2;

	echo "$n1 + $n2 = <b>$result</b>";
?><br>
<br>
<a href="calculator.php">Back</a>