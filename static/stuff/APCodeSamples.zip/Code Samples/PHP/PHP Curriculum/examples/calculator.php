<b>Simple Calculator (Addition)</b><br>
<br>
<form action="calculator_submit.php" method="post">
	<input type="text" name="n1"> + <input type="text" name="n2"> = <input type="submit" value="Let's find out!">
</form>