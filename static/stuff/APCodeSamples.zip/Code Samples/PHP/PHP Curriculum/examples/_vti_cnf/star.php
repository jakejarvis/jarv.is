vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Jul 2005 14:34:00 -0000
vti_extenderversion:SR|6.0.2.6353
vti_author:SR|JAKE\\Jake Jarvis
vti_modifiedby:SR|JAKE\\Jake Jarvis
vti_timecreated:TR|16 Jul 2005 14:34:00 -0000
vti_cacheddtm:TX|16 Jul 2005 14:34:00 -0000
vti_filesize:IR|166
vti_cachedlinkinfo:VX|A|star_submit.php
vti_cachedsvcrellinks:VX|FAUS|examples/star_submit.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
vti_backlinkinfo:VX|assignments/star.htm
