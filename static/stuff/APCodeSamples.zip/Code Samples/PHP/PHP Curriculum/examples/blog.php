<b>My MySQL Blog</b><br>
<br>
<a href="blog_add.php">Add an Entry</a>
<br><br>
<?php
	$conn = mysql_connect ('localhost', 'jarvis_projects', 'jake0206')
		or die ("Could not connect to server localhost.");

	mysql_select_db ('jarvis_projects', $conn)
		or die ("Could not select database jarvis_projects.");

	$query = "SELECT * FROM blog";
	$result = mysql_query ($query)
		or die ($query);

	while ($entry = mysql_fetch_object ($result)) {
		echo "<b>$entry->title</b><BR>";
		echo "$entry->message<BR><BR>";
		echo "Posted by $entry->author<BR><BR><HR>";
	}

	mysql_close ($conn);
?>
