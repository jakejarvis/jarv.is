<?php
	mail($to, $subject, $message);
?>
<b>Email Client</b>
<br>
<br>
Successfully sent! <a href="email.php">Send another.</a>