<?php
	echo "One day, a $noun1 was walking through a $place and picked up a $noun2. \"$exp,\" the $noun1 said.";
?>