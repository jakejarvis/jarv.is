<?
	$id = $_GET['id'];

	if ($_POST['response']) post_response($id, $_POST['response']);

	$title = '"' . substr(get_rant_content($id), 0, 40) . '..." / Respond';

	$html .= '
  <div class="content center">
    <!-- rant content -->
    <h2><a href="/view/' . $id . '">';

	$html .= get_rant_content($id);

	$html .= '</a></h2>

    <!-- rant timestamp -->
    <span class="small">' . date("M j, Y g:i A T", strtotime(get_rant_timestamp($id))) . '</span>

    <div class="spacer"></div>';

  if (get_num_of_responses($id)) {
    $html .= "\n\n";
    $html .= '
    <!-- existing responses -->
    <h3>' . get_num_of_responses($id) . ' Response';

    if (get_num_of_responses($id) > 1) $html .= 's';

    $html .= '</h3>';

    $html .= "\n\n";

    $query = "SELECT response_content, response_time FROM responses WHERE rant_id = '$id'";
    $result = mysql_query($query) or die('Query failed!');

    $count = 1;

    while ($response = mysql_fetch_object($result)) {
      $html .= '
    <!-- response #' . $count . ' content -->
    <p>' . str_replace("\n", "<br />", $response->response_content) . '<br />
    <!-- response #' . $count . ' timestamp -->
    <span class="small">' . date("M j, Y g:i A T", strtotime($response->response_time)) . '</span></p>';
      $html .= "\n\n";

      $count++;
    }

    $html .= '
    <div class="spacer"></div>';
  }


  $html .= '

    <!-- response form -->
    <h3>Add Your Thoughts</h3>

    <p class="kindasmall">Just like rants, all responses are completely anonymous.</p>

    <form action="' . $_SERVER['REQUEST_URI'] . '" method="post">
      <p><textarea name="response"></textarea></p>
      <p><input class="submit" type="submit" value="Add Response" /></p>
    </form>
  </div>';
?>