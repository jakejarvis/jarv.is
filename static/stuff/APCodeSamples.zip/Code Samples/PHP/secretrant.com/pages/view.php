<?
  if (!$_GET['id']) {
    $id = get_recent_rant_id();
  } else {
    $id = $_GET['id'];
    $title = '"' . substr(get_rant_content($id), 0, 40) . '..."';
  }


	$html .= '
  <div class="content center">
    <!-- rant content -->
    <h1><a href="/view/' . $id . '">';

	$html .= get_rant_content($id);

	$html .= '</a></h1>

    <!-- rant timestamp -->
    <span class="small">' . date("M j, Y g:i A T", strtotime(get_rant_timestamp($id))) . '</span>

    <div class="spacer"></div>

    <!-- buttons (working on css solution) -->
    <table width="100%">
      <tr>
        <td align="center" class="buttons">
          <table width="402">
            <tr>
              <td align="center" class="buttons">
                <ul>
                  <li><a href="/respond/' . $id . '">Talk About This</a></li>
                  <li><a href="/view/' . get_random_rant_id($id) . '">Another One, Please</a></li>
                </ul>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </div>';
?>