<?
  $html = "";
  include("../includes/db.php");
  include("../includes/functions.php");
  include($_GET['page']);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Secret Rant / <?= $title ?><? if(!$title) echo 'Anonymous Anger Management' ?></title>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="Secret Rant is a outlet for anger at the end of a long day where anyone can rant without being identified." />
  <meta name="keywords" content="secretrant,secret rant,jake jarvis,jarvis,anger,anger management,anonymous,steam,complain" />

  <style type="text/css" media="all">
    @import "/css/global.css";
  </style>

  <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
  <link rel="alternate" type="application/rss+xml" title="RSS" href="/index.xml" />
</head>

<!-- <?= md5(rand()) //keep the page fresh ?> -->

<body>
  <!-- google ads -->
  <div class="advert">
    <script type="text/javascript"><!--
    google_ad_client = "pub-0157483198761155";
    google_ad_width = 234;
    google_ad_height = 60;
    google_ad_format = "234x60_as";
    google_ad_type = "text";
    //2006-12-20: Secret Rant
    google_ad_channel = "2330574032";
    google_color_border = "FFFFFF";
    google_color_bg = "FFFFFF";
    google_color_link = "CC3333";
    google_color_text = "666666";
    google_color_url = "666666";
    //--></script>
    <script type="text/javascript"
      src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
    </script>
  </div>

  <!-- logo -->
  <a class="logo" href="/">Secret Rant</a>

  <!-- navigation bar -->
  <div class="nav">
    <ul>
      <li><a class="nav-button" href="/">Recent</a></li>
      <li><a class="nav-button" href="/add">Add Your Rant</a></li>
      <li><a class="nav-button" href="/browse">Browse</a></li>
      <li><a class="nav-button" href="/help">Help</a></li>
    </ul>
  </div>

<?= $html ?>


  <!-- google analytics -->
  <script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
  </script>
  <script type="text/javascript">
  _uacct = "UA-246957-4";
  urchinTracker();
  </script>

</body>
</html>