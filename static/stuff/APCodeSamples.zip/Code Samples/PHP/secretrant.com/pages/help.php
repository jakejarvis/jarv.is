<?

$title = 'Help';
$html .= '
  <div class="content">
    <h3>What is Secret Rant?</h3>
    <p>Secret Rant is a new site where anyone on the net can let out some steam at the end of a long day without being identified.</p>

    <h3>What does that mean?</h3>
    <p>Think of Secret Rant as screaming into a pillow. You can rant about your mentally-insane boss as much as you\'d like, but he\'ll never be able to identify you (unless you post revealing information, of course).</p>

    <h3>Do you store any information about me when I rant?</h3>
    <p>Only your network\'s IP address is logged. This address will never be shared with anyone, including viewers, and is only used for spam prevention. This cannot be used to identify you by Secret Rant moderators.</p>

    <h3>Will my crazy coworker ever find out I complained about him?</h3>
    <p>We will never display information that could possibly be used to identify you, such as your network\'s IP address.</p>

    <h3>I noticed you didn\'t really answer the last question.</h3>
    <p>There is always the possibility that someone will be able to identify you based on what you write. When ranting, be sure not to include any revealing information about your identity or the identity of the person you\'re ranting about if you want to remain anonymous.</p>

    <h3>In order to rant, what information do I need to give you?</h3>
    <p>Nothing! <a href="/add">Type your rant</a> and press the big red button. That\'s all there is to it. Secret Rant does not ask you for any personal information.</p>

    <h3>How about responses? Are those anonymous too?</h3>
    <p>Absolutely. Adding your opinion on a rant is as simple as ranting itself. Just find a rant to talk about, type your opinion in the big box, and press the red button.</p>

    <h3>I don\'t see this feature. What\'s up with that?</h3>
    <p>We\'ll be adding new features to the site for as long as it\'s around. If you think of something you\'d like to see implemented, feel free to email us at <a href="mailto:comments@secretrant.com">comments@secretrant.com</a>. (Check back in a few months for user-controlled moderation, the option for non-anonymous responses, and more.)</p>

    <h3>What a wonderful idea! How can I help you guys out?</h3>
    <p>Thanks for your support! Feel free to tell your friends about us, blog about us, or <a href="http://digg.com/submit?phase=2&url=http%3A%2F%2Fsecretrant.com%2F&title=Secret+Rant+-+An+anonymous+anger+outlet&bodytext=Secret+Rant+is+a+new+site+where+anyone+on+the+net+can+let+out+some+steam+at+the+end+of+a+long+day--without+being+identified.+It%27s+extremely+simple+and+surprisingly+satisfying.+Neat+idea.&topic=tech_news">Digg us</a>. However, the best thing you can do to help us is to actively rant and respond to rants.</p>
  </div>

';

?>