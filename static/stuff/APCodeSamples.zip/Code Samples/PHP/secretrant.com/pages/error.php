<?
	$title = 'Error';
	$html = '
  <div class="content center">
    <p>Looks like you\'ve encountered a little dent in our system. If you\'d like to help us out, <a href="mailto:comments@secretrant.com">shoot us an email</a> with as much details as possible, and we\'ll look into the problem.</p>
    <p>In the meantime, it\'s probably best to click on the Secret Rant logo above and start back on the homepage.</p>
  </div>';
?>