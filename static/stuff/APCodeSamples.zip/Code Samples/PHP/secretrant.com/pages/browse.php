<?
  $title = 'Browse';

  $page = $_GET['brpg'];
  if ( !$page ) $page = 1;
  if($page > 1) $title .= ' / Page ' . $page;
  $page -= 1;
  $start = $page * 5;

  $query = "SELECT rant_id FROM rants ORDER BY rant_id DESC LIMIT $start,5";
  $result = mysql_query ($query) or die ($query);

  while($rant = mysql_fetch_object($result)) {
    $id = $rant->rant_id;
    $html .= '
    <div class="content center">
      <!-- rant content -->
      <h1><a href="/view/' . $id . '">';

  	$html .= get_rant_content($id);

  	$html .= '</a></h1>

      <!-- rant timestamp -->
      <span class="small">' . date("M j, Y g:i A T", strtotime(get_rant_timestamp($id))) . '</span>
    </div>';
  }

  $html .= printPages($page);

  function printPages($page) {
    $query = "SELECT rant_id FROM rants";
    $result = mysql_query ($query) or die ($query);
    $total = mysql_num_rows($result);

    $prevpage = $page;
    $nextpage = $page + 2;
    $start = $page * 5;
    $first = $start + 1;
    $last = $first + 11;

    $query = "SELECT rant_id FROM rants ORDER BY rant_id DESC LIMIT $start,5";
    $result = mysql_query ($query) or die ($query);
    $max = mysql_num_rows($result);

    if ($max < $last) $last = $max + $start;

    $html .= '

    <table class="pages">
      <tr>
        <td class="pages-left">';
    if ( $prevpage != 0 ) {
      $html .= '<a href="/browse/' . $prevpage . '"><< Previous</a>';
    }

    $html .= '</td>
        <td class="pages-count">' . $first . ' - ' . $last . ' of ' . $total . '</td>
        <td class="pages-right">';

    if ($last < $total) {
      $html .= '<a href="/browse/' . $nextpage . '">Next >></a>';
    }

    $html .= '</td>
      </tr>
    </table>';

    return $html;
  }
?>