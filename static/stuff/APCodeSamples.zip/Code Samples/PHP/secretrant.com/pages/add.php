<?
	if($_POST['rant']) {
		$id = post_rant($_POST['rant']);
		header("Location: /view/" . $id);
	}

	$title = 'Add a Rant';
	$html .= '
  <div class="content center">
    <!-- the yada yada -->
    <p>Bad day at work? The jerk in the cubicle across to you getting on your nerves? Have the urge to say something you promised you wouldn\'t? Is something else eating you up inside?</p>
    <p>Don\'t worry, all rants are completely anonymous. Let us know what\'s really on your mind. If you don\'t add revealing information, nobody will know it\'s you. We promise.</p>

    <!-- rant form -->
    <form action="' . $_SERVER['REQUEST_URI'] . '" method="post">
      <p><textarea name="rant"></textarea></p>
      <p><input class="submit" type="submit" value="Rant Away" /></p>
    </form>
  </div>';
?>