<?
  if ($_POST['query']) {
    header('/search/'.$_POST['query']);
  } else if ($_GET['query']) {
    //show results
    $html .= $_GET['query'];
  } else {
    //show search form
    $html .= '
  <div class="content center">
    <!-- search form -->
    <form action="' . $_SERVER['REQUEST_URI'] . '" method="post">
      <label for="query">Search Term</label>
      <input type="text" name="query" />
    </form>
  </div>';
  }
?>