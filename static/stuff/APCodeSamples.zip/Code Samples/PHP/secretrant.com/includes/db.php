<?
	$sql_server = "";
	$sql_db = "";
	$sql_user = "";
	$sql_password = "";

	$link = mysql_connect($sql_server, $sql_user, $sql_password)
		or die("Connection to server failed.");

	mysql_select_db($sql_db, $link)
		or die('Database selection failed.');
?>