<?

  /************************************************************
  * Rant Functions
  ************************************************************/
  
	function post_rant($content) {
		$query = "INSERT INTO rants (rant_content, rant_user_ip) VALUES ('" . htmlspecialchars($content, ENT_QUOTES) . "', '" . $_SERVER['REMOTE_ADDR'] . "')";
		mysql_query($query) or die('Query failed!');

		$query = "SELECT rant_id FROM rants ORDER BY rant_id DESC LIMIT 1";
		$result = mysql_query($query) or die('Query failed!');
		$rant = mysql_fetch_object($result);

		return $rant->rant_id;
	}

	function get_rant_content($id) {
		$query = "SELECT rant_content FROM rants WHERE rant_id = '" . $id . "'";
		$result = mysql_query($query) or die('Query failed!');
		$rant = mysql_fetch_object($result);

		return $rant->rant_content;
	}

	function get_rant_timestamp($id) {
		$query = "SELECT rant_timestamp FROM rants WHERE rant_id = '" . $id . "'";
		$result = mysql_query($query) or die('Query failed!');
		$rant = mysql_fetch_object($result);

		return $rant->rant_timestamp;
	}

	function get_recent_rant_id() {
		$query = "SELECT rant_id FROM rants ORDER BY rant_id DESC LIMIT 1";
		$result = mysql_query($query) or die('Query failed!');
		$rant = mysql_fetch_object($result);

		return $rant->rant_id;
	}

	function get_random_rant_id($current) {
		$query = "SELECT rant_id FROM rants WHERE rant_id != '" . $current . "' ORDER BY RAND() LIMIT 1";
		$result = mysql_query($query) or die('Query failed!');
		$rant = mysql_fetch_object($result);

		return $rant->rant_id;
	}

  /************************************************************
  * Response Functions
  ************************************************************/

  function post_response($rantid, $content) {
		$content = htmlentities($content);

		$query = "INSERT INTO responses (rant_id, response_content, response_user_ip) VALUES ('" . $rantid . "', '" . $content . "', '" . $_SERVER['REMOTE_ADDR'] . "')";
		mysql_query($query) or die('Query failed!');

		return true;
  }

  function get_num_of_responses($rantid) {
    $query = "SELECT response_id FROM responses WHERE rant_id = '$rantid'";
    $result = mysql_query($query) or die('Query failed!');
    
    return mysql_num_rows($result);
  }
?>