

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Secret Rant</title>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="keywords" content="secret rant " />

  <style type="text/css" media="all">
    p {font-family: "Lucida Grande", verdana, arial, sans-serif; font-size: 14px;}
  </style>
</head>

<body>
	<table width="100%" height="100%">
	  <tr>
	    <td width="100%" height="100%" align="center" valign="middle">
	      <img src="/img/shout.gif" />
	      <p>Soon</p>
	    </td>
	  </tr>
	</table>

	<!-- google analytics -->
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
	</script>
	<script type="text/javascript">
	_uacct = "UA-246957-4";
	urchinTracker();
	</script>

</body>
</html>